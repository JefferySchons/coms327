int f2c(int fahrenheit)
{
  return ((fahrenheit - 32) * 5) / 9;
}
