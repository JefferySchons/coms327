int f2c(int fahrenheit);
int c2f(int celcius);
