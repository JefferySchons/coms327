int c2f(int celcius)
{
  return 32 + (celcius * 9) / 5;
}
