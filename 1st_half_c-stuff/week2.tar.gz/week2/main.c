#include <stdio.h>

#include "cf.h"

int main(int argc, char *argv[])
{
  printf("Water boils at %d degrees celcius.\n", f2c(212));

  return 0;
}
