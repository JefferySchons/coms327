#include <math.h>

int main(int argc, char *argv[])
{
  log(M_PI);

  return 0;
}
