#ifndef PATH_H
#define PATH_H

#include "room.h"

void corridor_connect(Room, Room);

#endif
